sap.ui.define([
"asaod/ASAOD/controller/BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("asaod.ASAOD.controller.App", {

	});
});